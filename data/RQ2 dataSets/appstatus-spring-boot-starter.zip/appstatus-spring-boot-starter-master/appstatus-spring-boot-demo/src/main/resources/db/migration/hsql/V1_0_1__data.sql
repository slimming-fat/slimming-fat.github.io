insert into sample_table (text) values ('text 1');
insert into sample_table (text) values ('text 2');
insert into sample_table (text) values ('text 3');