package net.sf.appstatus.boot.web;

import org.springframework.boot.SpringBootConfiguration;

@EnableAppStatus
@SpringBootConfiguration
public class AppStatusTestConfig {

}
