package org.zapodot.hystrix.bundle;

import io.dropwizard.Configuration;

public class AppConfiguration extends Configuration {

}
