package com.xyz.testapp;

public class App {

	/** Comment added.
	 * Added more comment.
	 */
	public static void main(String[] args) {
		System.out.println("This is App");
	}

}
