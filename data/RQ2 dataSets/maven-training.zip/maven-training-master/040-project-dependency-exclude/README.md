
Shows also omitted parts:
mvn dependency:tree -Dverbose=true
