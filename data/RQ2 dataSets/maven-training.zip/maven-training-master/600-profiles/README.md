Maven Plattform Profile Activation

