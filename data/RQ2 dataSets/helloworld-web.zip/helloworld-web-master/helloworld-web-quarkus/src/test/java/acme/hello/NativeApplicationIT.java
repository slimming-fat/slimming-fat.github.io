package acme.hello;

import io.quarkus.test.junit.SubstrateTest;

@SubstrateTest
public class NativeApplicationIT extends ApplicationTest {
    // Execute the same tests but in native mode.
}
