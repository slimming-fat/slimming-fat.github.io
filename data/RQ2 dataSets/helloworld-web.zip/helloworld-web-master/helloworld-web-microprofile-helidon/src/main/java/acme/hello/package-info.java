/**
 * Quickstart MicroProfile example.
 */
package acme.hello;