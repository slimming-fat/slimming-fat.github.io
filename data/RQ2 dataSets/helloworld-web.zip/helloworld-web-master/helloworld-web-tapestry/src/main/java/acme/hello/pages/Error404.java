package acme.hello.pages;

public class Error404 {
}