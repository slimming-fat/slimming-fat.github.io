/**
 * Spring MVC REST controllers.
 */
package acme.hello.web.rest;
