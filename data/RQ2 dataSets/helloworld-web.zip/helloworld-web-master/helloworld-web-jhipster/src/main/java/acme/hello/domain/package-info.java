/**
 * JPA domain objects.
 */
package acme.hello.domain;
