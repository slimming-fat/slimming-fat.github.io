/**
 * Spring Security configuration.
 */
package acme.hello.security;
