/**
 * Spring Data JPA repositories.
 */
package acme.hello.repository;
