/**
 * Service layer beans.
 */
package acme.hello.service;
