import 'jest-preset-angular';
import './jest-global-mocks';
