
public class JavaApiConfig {

	public void test() {
		
		
	}
}
