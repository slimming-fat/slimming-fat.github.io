/**
 * 
 */
/**
 * @author percy
 *
 */
package boot.dubbo.simple.client.config;