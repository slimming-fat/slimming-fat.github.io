/**
 * Service classes used to execute behaviors.
 *
 * @author gregswindle
 * @since 0.0.1-SNAPSHOT
 * @version 0.0.1-SNAPSHOT
 */
package net.swindle.springdemo.serviceimpl;
