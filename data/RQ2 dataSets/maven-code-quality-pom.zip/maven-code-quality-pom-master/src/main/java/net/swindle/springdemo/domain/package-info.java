/**
 * Domain classes used to model the real world.
 *
 * @author gregswindle
 * @since 0.0.1-SNAPSHOT
 * @version 0.0.1-SNAPSHOT
 */
package net.swindle.springdemo.domain;
