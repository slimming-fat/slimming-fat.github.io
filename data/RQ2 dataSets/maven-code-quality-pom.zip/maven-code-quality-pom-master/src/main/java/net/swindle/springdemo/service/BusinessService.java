package net.swindle.springdemo.service;

public interface BusinessService {

  @SuppressWarnings("PMD")
  public String offerService(String companyName);

  @SuppressWarnings("PMD")
  public int revenue = 1000000;
}
