package com.nibado.example.datastores.hazelcast;

import com.nibado.example.datastores.sharedtests.BaseTopicIntegrationTest;

class HazelcastTopicIntegrationTest extends BaseTopicIntegrationTest {
}