package com.nibado.example.datastores.hazelcast;

import com.nibado.example.datastores.sharedtests.BaseCacheIntegrationTest;

class HazelcastCachingIntegrationTest extends BaseCacheIntegrationTest {
}