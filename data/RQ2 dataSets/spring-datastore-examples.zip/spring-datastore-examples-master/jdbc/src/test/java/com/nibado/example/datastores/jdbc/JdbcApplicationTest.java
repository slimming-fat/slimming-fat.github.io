package com.nibado.example.datastores.jdbc;

import com.nibado.example.datastores.sharedtests.BaseDbIntegrationTest;

class JdbcApplicationTest extends BaseDbIntegrationTest {

}