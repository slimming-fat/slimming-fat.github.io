package com.nibado.example.datastores.jpa;

import com.nibado.example.datastores.sharedtests.BaseDbIntegrationTest;

class JpaApplicationIntegrationTest extends BaseDbIntegrationTest {

}