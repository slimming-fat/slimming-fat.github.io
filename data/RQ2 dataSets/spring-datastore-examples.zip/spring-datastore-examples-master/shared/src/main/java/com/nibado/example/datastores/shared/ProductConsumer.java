package com.nibado.example.datastores.shared;

import java.util.List;

public interface ProductConsumer {
    List<Product> consumedProducts();
}
