package com.nibado.example.datastores.shared;

import java.util.List;

public record ProductsResponse(List<Product> products) {
}
