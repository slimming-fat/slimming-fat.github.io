package com.nibado.example.datastores.shared;

public interface ProductProducer {
    void produce(Product product);
}
