package com.soebes.training.maven.simple;

public class UnitTestBase {

	public static void message() {
		System.out.println(" ---> This is the Unit Test Base class. <----");
	}
}
