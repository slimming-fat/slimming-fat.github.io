#!/bin/bash
find . -maxdepth 2 -type f -name "pom.xml"
