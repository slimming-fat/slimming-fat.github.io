package com.soebes.maui.ut.inter;


public class Implementation {

    public boolean function(String parameter1) {
        if (parameter1.startsWith("function1")) {
            return true;
        }
        return false;
    }

}
