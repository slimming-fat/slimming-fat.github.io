@ParametersAreNonnullByDefault
package org.zalando.opentracing.jdbc.autoconfigure;

import javax.annotation.ParametersAreNonnullByDefault;
