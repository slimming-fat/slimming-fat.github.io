@ParametersAreNonnullByDefault
package org.zalando.opentracing.jdbc.span;

import javax.annotation.ParametersAreNonnullByDefault;
