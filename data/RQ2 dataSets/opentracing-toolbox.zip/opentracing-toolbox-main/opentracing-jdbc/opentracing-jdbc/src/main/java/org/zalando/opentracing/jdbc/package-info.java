@ParametersAreNonnullByDefault
package org.zalando.opentracing.jdbc;

import javax.annotation.ParametersAreNonnullByDefault;
