@ParametersAreNonnullByDefault
package org.zalando.opentracing.jdbc.operation;

import javax.annotation.ParametersAreNonnullByDefault;
