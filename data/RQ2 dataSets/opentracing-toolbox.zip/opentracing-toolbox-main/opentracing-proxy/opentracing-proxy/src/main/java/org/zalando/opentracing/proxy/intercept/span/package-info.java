@ParametersAreNonnullByDefault
package org.zalando.opentracing.proxy.intercept.span;

import javax.annotation.ParametersAreNonnullByDefault;
