@ParametersAreNonnullByDefault
package org.zalando.opentracing.proxy.listen.scope;

import javax.annotation.ParametersAreNonnullByDefault;
