@ParametersAreNonnullByDefault
package org.zalando.opentracing.proxy.intercept.log;

import javax.annotation.ParametersAreNonnullByDefault;
