@ParametersAreNonnullByDefault
package org.zalando.opentracing.proxy.base;

import javax.annotation.ParametersAreNonnullByDefault;
