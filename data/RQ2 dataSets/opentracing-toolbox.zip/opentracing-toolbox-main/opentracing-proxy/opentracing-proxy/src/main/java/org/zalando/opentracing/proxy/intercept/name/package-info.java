@ParametersAreNonnullByDefault
package org.zalando.opentracing.proxy.intercept.name;

import javax.annotation.ParametersAreNonnullByDefault;
