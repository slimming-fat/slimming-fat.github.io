@ParametersAreNonnullByDefault
package org.zalando.opentracing.proxy.listen.span;

import javax.annotation.ParametersAreNonnullByDefault;
