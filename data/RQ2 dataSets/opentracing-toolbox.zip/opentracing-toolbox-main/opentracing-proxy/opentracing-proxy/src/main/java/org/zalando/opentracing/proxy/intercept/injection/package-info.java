@ParametersAreNonnullByDefault
package org.zalando.opentracing.proxy.intercept.injection;

import javax.annotation.ParametersAreNonnullByDefault;
