@ParametersAreNonnullByDefault
package org.zalando.opentracing.flowid;

import javax.annotation.ParametersAreNonnullByDefault;
