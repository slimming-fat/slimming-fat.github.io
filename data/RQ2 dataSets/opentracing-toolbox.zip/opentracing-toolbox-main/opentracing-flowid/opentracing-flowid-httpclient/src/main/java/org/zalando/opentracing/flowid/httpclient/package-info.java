@ParametersAreNonnullByDefault
package org.zalando.opentracing.flowid.httpclient;

import javax.annotation.ParametersAreNonnullByDefault;
