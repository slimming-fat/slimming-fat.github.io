package tamiflex;


import com.englishtown.vertx.jersey.examples.integration.JacksonIntegrationTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({JacksonIntegrationTest.class
       })
public class AllTests {

}
