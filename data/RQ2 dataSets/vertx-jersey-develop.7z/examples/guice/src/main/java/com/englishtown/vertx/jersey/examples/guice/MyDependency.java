package com.englishtown.vertx.jersey.examples.guice;

/**
 * POJO for guice injection
 */
public interface MyDependency {
}
