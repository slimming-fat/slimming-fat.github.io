package com.englishtown.vertx.jersey.examples.guice.impl;

import com.englishtown.vertx.jersey.examples.guice.MyDependency;

/**
 * Default implementation of {@link com.englishtown.vertx.jersey.examples.guice.MyDependency}
 */
public class DefaultMyDependency implements MyDependency {
}
