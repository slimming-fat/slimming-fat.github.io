package cn.bugstack.design.dao;

import cn.bugstack.design.po.User;

public interface IUserDao {

     User queryUserInfoById(Long id);

}
