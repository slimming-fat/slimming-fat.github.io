package cn.bugstack.design.test;

import cn.bugstack.design.Singleton_07;
import org.junit.Test;

public class ApiTest {

    @Test
    public void test() {
        Singleton_07.INSTANCE.test();
    }

}
