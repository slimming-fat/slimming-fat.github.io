package cn.bugstack.design.rpc.test.service;

public interface HelloService {

    void echo();

}
