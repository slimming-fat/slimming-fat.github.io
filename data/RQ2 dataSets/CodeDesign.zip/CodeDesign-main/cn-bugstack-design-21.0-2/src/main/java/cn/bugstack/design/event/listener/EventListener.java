package cn.bugstack.design.event.listener;

import cn.bugstack.design.LotteryResult;

public interface EventListener {

    void doEvent(LotteryResult result);

}
