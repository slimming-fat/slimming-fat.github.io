package cn.bugstack.design.rpc.export.domain;

public class Hi {

    private String userName;
    private String sayMsg;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSayMsg() {
        return sayMsg;
    }

    public void setSayMsg(String sayMsg) {
        this.sayMsg = sayMsg;
    }
}
