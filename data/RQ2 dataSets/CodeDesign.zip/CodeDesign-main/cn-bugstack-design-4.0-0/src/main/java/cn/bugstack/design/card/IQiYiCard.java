package cn.bugstack.design.card;

/**
 * 模拟爱奇艺视频卡，对象类
 */
public class IQiYiCard {

     // 卡券的一些信息

}
