package cn.bugstack.design.goods;

/**
 * 模拟商品信息，对象类
 */
public class GoodsInfo {



}
