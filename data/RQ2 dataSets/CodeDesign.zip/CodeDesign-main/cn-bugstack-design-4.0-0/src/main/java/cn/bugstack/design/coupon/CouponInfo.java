package cn.bugstack.design.coupon;

/**
 * 模拟优惠券，对象类
 */
public class CouponInfo {

    // 卡券的一些信息

}
