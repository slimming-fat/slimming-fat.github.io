package cn.bugstack.design;

public interface LotteryService {

    LotteryResult doDraw(String uId);

}
