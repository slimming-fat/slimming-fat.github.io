package cn.bugstack.design;

public interface OrderAdapterService {

    boolean isFirst(String uId);

}
