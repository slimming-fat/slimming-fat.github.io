package cn.bugstack.design.rpc.domain;

public class LocalServerInfo {

    public static String LOCAL_HOST;  //本地启动地址
    public static int LOCAL_PORT;     //本地启动IP

}
