package cn.bugstack.design.pay.mode;

public interface IPayMode {

    boolean security(String uId);

}
