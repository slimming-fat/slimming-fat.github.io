package cn.bugstack.design.domain.rule.service.logic;

public class LogicConfig {
}
