package cn.bugstack.design;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DDDApplication {

    public static void main(String[] args) {
        SpringApplication.run(DDDApplication.class, args);
    }

}
