package cn.bugstack.design.interfaces.dto;

public class TreeDTO {

    private Long treeId;

    public Long getTreeId() {
        return treeId;
    }

    public void setTreeId(Long treeId) {
        this.treeId = treeId;
    }

}
