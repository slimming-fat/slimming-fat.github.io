package cn.bugstack.design.lang;

public interface Iterable<E> {

    Iterator<E> iterator();

}
