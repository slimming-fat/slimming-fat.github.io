package tamiflex;


import org.itstack.demo.design.test.ApiTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ApiTest.class
       })
public class AllTests {

}
