package org.itstack.demo.design.goods;

public class GoodsInfo {



}
