package org.itstack.demo.design.pay.mode;

public interface IPayMode {

    boolean security(String uId);

}
