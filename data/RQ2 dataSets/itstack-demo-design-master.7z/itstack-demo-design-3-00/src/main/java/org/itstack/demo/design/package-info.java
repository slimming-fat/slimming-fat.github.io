/**
 * 装修材料
 * 吊顶；一级、二级
 * 涂料；多乐士(Dulux)、立邦
 * 地砖(tile)；东鹏瓷砖、马可波罗(MARCO POLO)
 * 地板(floor)；德尔(Der)、圣象
 */
package org.itstack.demo.design;