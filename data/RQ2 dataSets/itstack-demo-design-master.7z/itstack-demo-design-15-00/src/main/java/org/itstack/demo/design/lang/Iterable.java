package org.itstack.demo.design.lang;

public interface Iterable<E> {

    Iterator<E> iterator();

}
