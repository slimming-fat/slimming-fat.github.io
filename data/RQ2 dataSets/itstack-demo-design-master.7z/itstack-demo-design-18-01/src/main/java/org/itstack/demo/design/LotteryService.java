package org.itstack.demo.design;

public interface LotteryService {

    LotteryResult doDraw(String uId);

}
