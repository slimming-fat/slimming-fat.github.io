---
name: "\U0001F680 Feature Request"
about: I have a suggestion
---

## Feature Request

> 1.  **For English only**, other languages will not accept.
> 2. Please pay attention on issues you submitted, because we maybe need more details.
> 3. If no response anymore and we cannot make decision by current information, we will **close it**.

### Describe the feature you would like.
