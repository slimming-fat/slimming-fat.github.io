---
name: "\U0001F41B Bug Report"
about: Something isn't working as expected
---

## Bug Request

> 1.  **For English only**, other languages will not accept.
> 2. Please pay attention on issues you submitted, because we maybe need more details.
> 3. If no response anymore and we cannot make decision by current information, we will **close it**.

### Describe your problem

### Expected behavior

### Actual behavior

### Reason analyze (If you can)

### Example codes for reproduce this issue (such as a github link).
