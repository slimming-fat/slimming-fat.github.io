/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.zergclan.wormhole.test.integration.framework.container.storage;

import com.zaxxer.hikari.HikariDataSource;
import com.zergclan.wormhole.tool.constant.MarkConstant;
import com.zergclan.wormhole.test.integration.framework.container.wait.ConnectionWaitStrategy;
import com.zergclan.wormhole.test.integration.framework.util.PathGenerator;
import com.zergclan.wormhole.test.integration.framework.container.DockerITContainer;
import com.zergclan.wormhole.test.integration.framework.util.URLGenerator;
import org.testcontainers.containers.BindMode;

import javax.sql.DataSource;
import java.sql.DriverManager;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Abstract database IT container.
 */
public abstract class StorageITContainer extends DockerITContainer {
    
    private static final String CONTAINER_PATH = "/docker-entrypoint-initdb.d/";
    
    private final String databaseType;
    
    private final String assertPartType;
    
    private final Map<String, DataSource> dataSources = new LinkedHashMap<>();
    
    public StorageITContainer(final String identifier, final String dockerImageName, final String scenario, final String databaseType, final String assertPartType) {
        super(identifier, scenario, dockerImageName);
        this.databaseType = databaseType;
        this.assertPartType = assertPartType;
    }
    
    @Override
    protected void configure() {
        String initSqlPath = PathGenerator.generateInitSqlPath(getScenario(), assertPartType, databaseType);
        withClasspathResourceMapping(initSqlPath, CONTAINER_PATH, BindMode.READ_ONLY);
        withExposedPorts(getDefaultPort());
        setWaitStrategy(new ConnectionWaitStrategy(() -> DriverManager.getConnection(URLGenerator.generateJDBCUrl(databaseType, getFirstMappedPort()), getUsername(), getPassword())));
    }
    
    /**
     * Get {@link DataSource}.
     *
     * @param dataSourceName data source name
     * @return {@link DataSource}
     */
    public synchronized DataSource getDataSource(final String dataSourceName) {
        DataSource result = dataSources.get(dataSourceName);
        if (null == result) {
            result = createDataSource(dataSourceName);
            dataSources.put(dataSourceName, result);
        }
        return result;
    }
    
    private DataSource createDataSource(final String dataSourceName) {
        HikariDataSource result = new HikariDataSource();
        result.setDriverClassName(getDriverClassName());
        String jdbcUrl = getJdbcUrl(getHost(), getMappedPort(getDefaultPort()), dataSourceName);
        result.setJdbcUrl(jdbcUrl);
        result.setUsername(getUsername());
        result.setPassword(getPassword());
        result.setTransactionIsolation(getTransactionIsolation());
        result.setPoolName(getPoolName(dataSourceName));
        return result;
    }
    
    private String getPoolName(final String dataSourceName) {
        return getScenario() + MarkConstant.HYPHEN + databaseType + MarkConstant.HYPHEN + dataSourceName;
    }
    
    protected abstract String getDriverClassName();
    
    protected abstract String getJdbcUrl(String host, int port, String dataSourceName);
    
    protected abstract int getDefaultPort();
    
    protected abstract String getUsername();
    
    protected abstract String getPassword();
    
    protected abstract String getTransactionIsolation();
}
