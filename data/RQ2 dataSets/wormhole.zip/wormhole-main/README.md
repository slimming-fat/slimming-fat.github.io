![banner](https://github.com/zergclan/wormhole/blob/main/src/image/wormhole_banner.png)

# Wormhole

[![License](https://img.shields.io/badge/license-Apache%202-4EB1BA.svg)](https://www.apache.org/licenses/LICENSE-2.0.html)
![example workflow](https://github.com/zergclan/wormhole/actions/workflows/main.yml/badge.svg)
[![codecov](https://codecov.io/gh/zergclan/wormhole/branch/main/graph/badge.svg?token=4CH3PS7WP8)](https://codecov.io/gh/zergclan/wormhole)

Wormhole provides an out-of-the-box (OOTB) solution of data transform tool/platform.
