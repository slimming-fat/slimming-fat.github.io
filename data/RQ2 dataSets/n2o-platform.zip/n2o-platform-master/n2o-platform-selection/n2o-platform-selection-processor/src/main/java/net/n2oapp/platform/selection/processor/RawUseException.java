package net.n2oapp.platform.selection.processor;

public class RawUseException extends RuntimeException {
}
