package net.n2oapp.platform.jaxrs.api;

import java.util.List;

public class ListModel extends AbstractModel<List<IntegerModel>> {

    public ListModel() {
    }

    public ListModel(List<IntegerModel> value) {
        super(value);
    }

}