package net.n2oapp.platform.jaxrs.api;

public class IntegerModel extends AbstractModel<Integer> {

    public IntegerModel() {
    }

    public IntegerModel(Integer value) {
        super(value);
    }
    
}
