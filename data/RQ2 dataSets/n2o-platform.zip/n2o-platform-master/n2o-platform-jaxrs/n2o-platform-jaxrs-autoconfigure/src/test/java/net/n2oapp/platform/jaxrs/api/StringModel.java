package net.n2oapp.platform.jaxrs.api;

public class StringModel extends AbstractModel<String> {

    public StringModel() {
    }

    public StringModel(String value) {
        super(value);
    }

}
