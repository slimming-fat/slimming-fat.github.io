package tamiflex;


import io.jsonwebtoken.jackson.io.JacksonDeserializerTest;
import io.jsonwebtoken.jackson.io.JacksonSerializerTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({JacksonDeserializerTest.class,
        JacksonSerializerTest.class
       })
public class AllTests {

}
