package tamiflex;

import org.junit.runner.JUnitCore;


public class MainAppTest {
    public static void main(String[] args) {
        System.out.println("Running tests!");
        JUnitCore engine = new JUnitCore();
        engine.run(AllTests.class);
//        Thread.currentThread().interrupt();
//        System.exit(0);
    }
}
