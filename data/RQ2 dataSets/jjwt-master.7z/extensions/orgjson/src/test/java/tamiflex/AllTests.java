package tamiflex;


import io.jsonwebtoken.orgjson.io.AndroidOrgJsonSerializerTest;
import io.jsonwebtoken.orgjson.io.OrgJsonDeserializerTest;
import io.jsonwebtoken.orgjson.io.OrgJsonSerializerTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({AndroidOrgJsonSerializerTest.class,
        OrgJsonDeserializerTest.class,
        OrgJsonSerializerTest.class
       })
public class AllTests {

}
