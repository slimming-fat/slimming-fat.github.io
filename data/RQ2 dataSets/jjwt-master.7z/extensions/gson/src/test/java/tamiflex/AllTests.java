package tamiflex;


import io.jsonwebtoken.gson.io.GsonDeserializerTest;
import io.jsonwebtoken.gson.io.GsonSerializerTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({GsonSerializerTest.class,
        GsonDeserializerTest.class
       })
public class AllTests {

}
