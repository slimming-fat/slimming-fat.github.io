package tamiflex;

import org.apache.logging.log4j.core.jackson.ExtendedLog4j2JsonModuleTest;
import org.apache.logging.log4j.core.jackson.JacksonJsonMessageSerializerTest;
import org.appenders.core.util.PropertiesUtilTest;
import org.appenders.log4j2.elasticsearch.*;
import org.appenders.log4j2.elasticsearch.backoff.BatchLimitBackoffPolicyTest;
import org.appenders.log4j2.elasticsearch.backoff.NoopBackoffPolicyTest;
import org.appenders.log4j2.elasticsearch.ecs.LogEventJacksonEcsJsonMixInTest;
import org.appenders.log4j2.elasticsearch.failover.*;
import org.appenders.log4j2.elasticsearch.json.jackson.JacksonJsonRawMessageSerializerTest;
import org.appenders.log4j2.elasticsearch.json.jackson.JacksonJsonStringMessageSerializerTest;
import org.appenders.log4j2.elasticsearch.spi.BatchEmitterServiceProviderLoadingOrderTest;
import org.appenders.log4j2.elasticsearch.spi.BatchEmitterServiceProviderTest;
import org.appenders.log4j2.elasticsearch.thirdparty.ReusableByteBufOutputStreamTest;
import org.appenders.log4j2.elasticsearch.util.SplitUtilTest;
import org.appenders.log4j2.elasticsearch.util.VersionTest;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;


import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;


public class MainAppTest {
    public static void main(String[] args) {
        LauncherDiscoveryRequest request = LauncherDiscoveryRequestBuilder
                .request()
                .selectors(
                        selectClass(ExtendedLog4j2JsonModuleTest.class),
                        selectClass(JacksonJsonMessageSerializerTest.class)
                )
                .build();

        Launcher launcher = LauncherFactory.create();

        SummaryGeneratingListener listener = new SummaryGeneratingListener();
        launcher.registerTestExecutionListeners(listener);

        launcher.execute(request);

        TestExecutionSummary summary = listener.getSummary();
        // 可以根据需要处理执行结果的摘要信息
        System.out.println(summary.getTestsSucceededCount());
        System.out.println(summary.getTestsFailedCount());
//        ConsoleLauncher.main("--scan-classpath");
    }
}
