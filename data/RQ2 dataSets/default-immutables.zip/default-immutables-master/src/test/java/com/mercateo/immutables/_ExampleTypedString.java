package com.mercateo.immutables;

import org.immutables.value.Value;

@Value.Immutable
@Wrapped
abstract class _ExampleTypedString extends Wrapper<String> {
}
