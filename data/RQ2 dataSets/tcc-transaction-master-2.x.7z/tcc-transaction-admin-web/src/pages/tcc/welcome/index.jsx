import React from 'react';

const page = () => {
  return (
    <div style={{margin: '15rem 22rem'}}>
      <h1 style={{fontSize: '30px'}}>欢迎来到TCC管理后台</h1>
    </div>
  )
}


export default page;
