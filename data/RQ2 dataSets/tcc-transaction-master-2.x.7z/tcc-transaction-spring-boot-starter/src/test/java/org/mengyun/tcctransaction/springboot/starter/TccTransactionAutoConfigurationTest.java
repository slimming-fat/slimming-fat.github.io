package org.mengyun.tcctransaction.springboot.starter;

import org.assertj.core.api.Assertions;
import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mengyun.tcctransaction.TccClient;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;

/**
 * @author Nervose.Wu
 * @date 2022/5/26 15:25
 */
public class TccTransactionAutoConfigurationTest {
    private static ConfigurableApplicationContext context;
    private final ApplicationContextRunner runner = new ApplicationContextRunner();
//            .withInitializer(new ConfigFileApplicationContextInitializer())
//            .withUserConfiguration(TestConfig.class);

    @Test
    public void tccClient() {
        runner.withPropertyValues("spring.application.name=tccClient", "spring.config.name=application-client")
                .run(ctx -> {
//                    Assertions.assertThat(ctx).hasSingleBean(TccClient.class);
                    context = ctx;
                });
    }

    @Configuration
    @EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, RedisAutoConfiguration.class})
    static class TestConfig {
    }

    @AfterClass
    public static void cleanup() {
        if (context != null) {
            context.close();
        }
    }
}
