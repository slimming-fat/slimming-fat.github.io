package tamiflex;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.mengyun.tcctransaction.springboot.starter.TccTransactionAutoConfigurationTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({TccTransactionAutoConfigurationTest.class
       })
public class AllTests {

}
