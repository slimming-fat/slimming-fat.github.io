package org.mengyun.tcctransaction.unittest.utils;

/**
 * Created by changmingxie on 12/4/15.
 */
public class UnitTest {

    public static volatile boolean CONFIRMING_EXCEPTION = false;
    public static volatile boolean TRYING_EXCEPTION = false;
}
