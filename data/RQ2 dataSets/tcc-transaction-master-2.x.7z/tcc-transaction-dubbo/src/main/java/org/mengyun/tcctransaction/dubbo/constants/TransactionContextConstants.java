package org.mengyun.tcctransaction.dubbo.constants;

/**
 * Created by changming.xie on 1/19/17.
 */
public class TransactionContextConstants {
    public static final String TRANSACTION_CONTEXT = "TRANSACTION_CONTEXT";

    public static final String CLUSTER_INTERCEPTOR_TAKE_EFFECT_MARK = "CLUSTER_INTERCEPTOR_TAKE_EFFECT_MARK";

    private TransactionContextConstants() {
    }
}
