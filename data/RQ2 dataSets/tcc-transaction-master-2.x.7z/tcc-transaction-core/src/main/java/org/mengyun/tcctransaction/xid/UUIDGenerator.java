package org.mengyun.tcctransaction.xid;

public interface UUIDGenerator {
    String generate();
}
