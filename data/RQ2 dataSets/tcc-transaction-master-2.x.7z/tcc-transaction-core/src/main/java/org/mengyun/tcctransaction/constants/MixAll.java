package org.mengyun.tcctransaction.constants;

public class MixAll {

    private MixAll(){
    }

    public static final String DOMAIN = "DOMAIN";
}
