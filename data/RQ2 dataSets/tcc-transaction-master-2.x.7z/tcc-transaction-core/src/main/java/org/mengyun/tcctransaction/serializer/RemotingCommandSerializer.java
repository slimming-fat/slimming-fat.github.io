package org.mengyun.tcctransaction.serializer;

import org.mengyun.tcctransaction.remoting.protocol.RemotingCommand;

public interface RemotingCommandSerializer extends ObjectSerializer<RemotingCommand> {
}
