package org.mengyun.tcctransaction.serializer;

import org.mengyun.tcctransaction.storage.TransactionStore;

public interface TransactionStoreSerializer extends ObjectSerializer<TransactionStore> {
}