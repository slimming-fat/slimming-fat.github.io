package org.mengyun.tcctransaction.serializer;


import org.mengyun.tcctransaction.transaction.Transaction;

/**
 * Created by changming.xie on 09/12/19.
 */
public interface TransactionSerializer extends ObjectSerializer<Transaction> {
}
