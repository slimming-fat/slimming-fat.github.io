package org.mengyun.tcctransaction.repository;

//
public enum StorageMode {
    ALONE,
    CENTRAL
}
