package org.mengyun.tcctransaction.discovery.loadbalance;

/**
 * @author Nervose.Wu
 * @date 2022/5/12 18:39
 */
public enum LoadBalanceType {
    Random,
    RoundRobin,
    ;
}
