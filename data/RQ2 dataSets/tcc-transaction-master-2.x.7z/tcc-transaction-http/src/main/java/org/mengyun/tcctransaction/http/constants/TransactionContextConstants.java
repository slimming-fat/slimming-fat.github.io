package org.mengyun.tcctransaction.http.constants;

public class TransactionContextConstants {

    public static final String TRANSACTION_CONTEXT = "transactionContext";

    private TransactionContextConstants() {
    }
}
