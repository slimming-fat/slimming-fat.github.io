package org.tcctransaction.sample.multiple.tier.pay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleTierPayWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultipleTierPayWebApplication.class, args);
    }
}