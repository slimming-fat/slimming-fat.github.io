package org.tcctransaction.sample.multiple.tier.trade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleTierTradeWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultipleTierTradeWebApplication.class, args);
    }
}
