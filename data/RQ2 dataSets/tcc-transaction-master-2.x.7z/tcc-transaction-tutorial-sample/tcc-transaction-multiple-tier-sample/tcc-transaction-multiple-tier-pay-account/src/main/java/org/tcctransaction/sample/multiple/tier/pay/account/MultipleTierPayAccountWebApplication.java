package org.tcctransaction.sample.multiple.tier.pay.account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleTierPayAccountWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultipleTierPayAccountWebApplication.class, args);
    }
}