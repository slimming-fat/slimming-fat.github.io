package org.tcctransaction.sample.multiple.tier.trade.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MultipleTierTradeOrderWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultipleTierTradeOrderWebApplication.class, args);
    }
}