package org.tcctransaction.sample.multiple.tier.trade.point;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleTierTradePointWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultipleTierTradePointWebApplication.class, args);
    }
}
