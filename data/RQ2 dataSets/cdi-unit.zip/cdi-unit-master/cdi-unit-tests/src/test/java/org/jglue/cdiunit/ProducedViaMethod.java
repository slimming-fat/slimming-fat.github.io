package org.jglue.cdiunit;

public class ProducedViaMethod {
	public ProducedViaMethod(int foo) {
		
	}
}
