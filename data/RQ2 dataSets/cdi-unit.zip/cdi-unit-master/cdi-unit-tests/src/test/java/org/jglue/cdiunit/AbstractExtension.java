package org.jglue.cdiunit;

import javax.enterprise.inject.spi.Extension;

public abstract class AbstractExtension implements Extension {

}

