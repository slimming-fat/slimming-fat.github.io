package org.jglue.cdiunit.packagetest.impl2;

import org.jglue.cdiunit.packagetest.PackageInterface;

public class PackageImpl2 implements PackageInterface {

}
