package org.jglue.cdiunit;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({InheretedExtension.class})
public class ExtensionInheritanceTest {

@Test
public void test() {

}
}