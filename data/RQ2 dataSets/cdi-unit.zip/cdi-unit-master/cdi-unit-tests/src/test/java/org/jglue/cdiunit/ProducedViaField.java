package org.jglue.cdiunit;

public class ProducedViaField {
	public ProducedViaField(int foo) {
		
	}
}
