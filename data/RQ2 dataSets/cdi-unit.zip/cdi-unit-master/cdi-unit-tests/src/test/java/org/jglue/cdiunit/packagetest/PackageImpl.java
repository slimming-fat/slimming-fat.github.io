package org.jglue.cdiunit.packagetest;

public class PackageImpl implements PackageInterface {

}
