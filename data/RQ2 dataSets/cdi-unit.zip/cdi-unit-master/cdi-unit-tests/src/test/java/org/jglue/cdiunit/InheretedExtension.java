package org.jglue.cdiunit;
public class InheretedExtension extends AbstractExtension {

}

