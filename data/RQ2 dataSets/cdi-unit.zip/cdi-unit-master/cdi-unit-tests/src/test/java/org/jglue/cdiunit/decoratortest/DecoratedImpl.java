package org.jglue.cdiunit.decoratortest;

/**
 * Created by pcasaes on 30/03/17.
 */
public class DecoratedImpl implements DecoratedInterface {

    @Override
    public int calculate() {
        return 0;
    }
}
