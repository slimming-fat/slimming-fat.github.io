package org.jglue.cdiunit.packagetest;

public interface PackageInterface {

}
