package org.jglue.cdiunit.internal.testscope;
