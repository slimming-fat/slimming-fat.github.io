package org.jglue.cdiunit.internal.deltaspike;
