package org.jglue.cdiunit.internal.junit;

public class InvalidRuleFieldUsageException extends RuntimeException {

	public InvalidRuleFieldUsageException(String message) {
		super(message);
	}

}
