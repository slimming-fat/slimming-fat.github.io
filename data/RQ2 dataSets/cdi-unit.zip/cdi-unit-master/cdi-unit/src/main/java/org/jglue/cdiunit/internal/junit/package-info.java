package org.jglue.cdiunit.internal.junit;
