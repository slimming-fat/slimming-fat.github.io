package org.jglue.cdiunit.internal.producerconfig;
