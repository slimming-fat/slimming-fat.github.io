package org.jglue.cdiunit.mockito;


public interface CService
{

}