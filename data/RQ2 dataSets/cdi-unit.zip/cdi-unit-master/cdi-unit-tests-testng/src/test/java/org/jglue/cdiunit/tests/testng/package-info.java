package org.jglue.cdiunit.tests.testng;
