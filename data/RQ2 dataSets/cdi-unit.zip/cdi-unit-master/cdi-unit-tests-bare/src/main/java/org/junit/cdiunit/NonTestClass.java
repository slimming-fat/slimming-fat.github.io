package org.junit.cdiunit;

public class NonTestClass {
	public void a() {

	}

}
