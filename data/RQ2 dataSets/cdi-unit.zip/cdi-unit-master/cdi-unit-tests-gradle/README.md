You can run the Gradle tests like this:

`gradle -PprojectVersionProp=4.0.3-SNAPSHOT -PweldVersionProp=3.0.4.Final check`
