package org.jglue.cdiunit.external;
public class ExternalImpl implements ExternalInterface {

}
