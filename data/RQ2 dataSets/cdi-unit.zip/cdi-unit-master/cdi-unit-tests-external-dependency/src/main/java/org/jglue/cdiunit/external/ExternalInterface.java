package org.jglue.cdiunit.external;

public interface ExternalInterface {

}
