#!/usr/bin/env bash

# Current strategy is, for each supported minor version of Weld, to test one early point release plus
# the most recent point release, plus some point releases which caused problems.
WELD_VERSIONS=(
  "1.1.34.Final"
  "1.1.16.Final"
  "1.1.14.Final"
)
