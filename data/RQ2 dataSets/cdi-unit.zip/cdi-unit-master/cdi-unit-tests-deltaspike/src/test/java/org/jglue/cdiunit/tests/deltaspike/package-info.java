package org.jglue.cdiunit.tests.deltaspike;
