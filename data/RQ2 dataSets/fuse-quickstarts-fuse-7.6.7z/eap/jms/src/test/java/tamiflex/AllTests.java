package tamiflex;


import com.redhat.consulting.fusequickstarts.eap.jms.route.ConsumerRouteTest;
import com.redhat.consulting.fusequickstarts.eap.jms.route.ProducerRouteTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ConsumerRouteTest.class,
        ProducerRouteTest.class
       })
public class AllTests {

}
