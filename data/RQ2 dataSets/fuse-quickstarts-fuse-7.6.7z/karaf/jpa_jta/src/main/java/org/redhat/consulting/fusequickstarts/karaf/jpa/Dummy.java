package org.redhat.consulting.fusequickstarts.karaf.jpa;

/**
 * Created by benja on 4/29/16.
 */
public class Dummy {

  public void crash() {
    throw new RuntimeException();
  }
}
