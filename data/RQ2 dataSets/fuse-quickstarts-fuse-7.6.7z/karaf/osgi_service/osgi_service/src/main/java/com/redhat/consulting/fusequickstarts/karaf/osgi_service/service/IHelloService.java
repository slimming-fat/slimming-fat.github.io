package com.redhat.consulting.fusequickstarts.karaf.osgi_service.service;

public interface IHelloService {
    public String sayMessage();
    public String sayHello(String pName);
}
