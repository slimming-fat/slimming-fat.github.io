package com.redhat.consulting.fusequickstarts.karaf.msf;

public class DictionaryConstants {

    public final static String ROUTE_ID = "routeId";

    public final static String HELLO_GREETING = "helloGreeting";
    public final static String HELLO_NAME = "helloName";

}
