package com.redhat.consulting.fusequickstarts.karaf.osgi_ds.api;

public interface IHelloService {
    public String sayMessage();
    public String sayHello(String pName);
}
