package com.redhat.consulting.fusequickstarts.springboot.routedeployment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RouteDeploymentApplication {

    public static void main(String[] args) {
        SpringApplication.run(RouteDeploymentApplication.class);
    }

}
