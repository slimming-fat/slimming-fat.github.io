package com.fizzed.bigmap.impl;

public class None {

    static public final None NONE = new None();

    private None() {}

}