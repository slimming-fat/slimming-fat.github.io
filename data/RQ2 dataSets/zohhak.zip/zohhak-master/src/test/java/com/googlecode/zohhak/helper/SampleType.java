package com.googlecode.zohhak.helper;

public class SampleType {

	public String value;

	public SampleType(String value) {
		this.value = value;
	}
}
