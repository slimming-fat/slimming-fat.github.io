package com.googlecode.zohhak.programmatic;

import org.junit.Test;

public class StandardTest {

	@Test
	public void method1() {}
	
	@Test
	public void method2() {}
	
}
