package com.googlecode.zohhak.helper;

public class SampleType2 {

	public String value;

	public SampleType2(String value) {
		this.value = value;
	}
	
}
