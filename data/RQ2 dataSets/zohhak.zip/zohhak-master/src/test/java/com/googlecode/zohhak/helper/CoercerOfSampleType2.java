package com.googlecode.zohhak.helper;

public class CoercerOfSampleType2 {

	public SampleType2 toSampleType2(String input) {
		return new SampleType2(input);
	}
}
