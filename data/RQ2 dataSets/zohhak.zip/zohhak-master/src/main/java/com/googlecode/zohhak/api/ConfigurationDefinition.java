package com.googlecode.zohhak.api;

public interface ConfigurationDefinition {

	String INHERIT = "\u0000";
	String DEFAULT_SEPARATOR = ",";

	String DEFAULT_STRING_BOUNDARY = "'";
}
